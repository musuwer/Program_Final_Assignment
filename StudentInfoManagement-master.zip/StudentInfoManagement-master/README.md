# StudentInfoManagement
Python tkinter + sqlite 学生信息管理系统     
东平西凑帮别人做的一个课设作业，实现了简单的增删改。   
数据库中默认用户名为：root ， 密码为：asdasdasd
